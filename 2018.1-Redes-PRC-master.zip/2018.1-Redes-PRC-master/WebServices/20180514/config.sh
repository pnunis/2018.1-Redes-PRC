#!/bin/sh
cd "/home/aluno/Área de Trabalho/2018.1-Redes-PRC/WebServices/20180514"
cp * /var/www/html/
chmod +x /var/www/html/exibe_dados.py
